CITY_NAME_ENDPOINT = 'http://192.168.1.102:8082/candidate/api/city/{city_name}'

#FETCH_CALL_CITY_ENDPOINT = 'http://192.168.1.102:8082/candidate/api/getAll/cities'

CANDIDATE_CITY_NAME = 'http://192.168.1.102:8082/candidate/api/candidateDetailsRaw/getAll'

GET_ALL_CITY_NAME = 'http://192.168.1.102:8082/candidate/api/getAll/cities'

UPDATE_CITY_NAME_IN_CITY_TABLE_END_POINT = 'http://192.168.1.102:8082/candidate/api/cities'