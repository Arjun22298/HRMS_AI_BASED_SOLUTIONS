API_NAME = 'gmail'
API_VERSION = 'v1'
SCOPES = ['https://mail.google.com/']
PROCESSED = "D:/hrms-application-parent/HrAtomation/final_extracted_pdf_path"
DOWNLOADS = "D:\HrAtomation\ResumeAiBased"


Resume = """if resume_matched(If resume_matched, otherwise Null) and given proper"""
FORMAT = """
{"resume_matched":"resume_matched",
"file_name":"file_name"},NextJson"""


