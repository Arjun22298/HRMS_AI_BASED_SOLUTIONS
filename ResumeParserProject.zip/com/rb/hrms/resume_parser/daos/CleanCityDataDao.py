import requests
from com.rb.hrms.resume_parser.constants.ResumeParsingWithAIConstants import *
from com.rb.hrms.resume_parser.constants.City_Url_EndPoint import *
import logging

class CandidateCitySearch:
    def __init__(self, tenant_id='redberyltech'):
        self.access_token = API_TOKEN
        self.tenant_id = tenant_id
        self.headers = {
            "Accept": "*/*",
            "User-Agent": "Thunder Client (https://www.thunderclient.com)",
            "X-TenantID": f"{self.tenant_id}",
            "Authorization": f"Bearer {self.access_token}"}

    def city_name_parse_by_name(self, city_name):
        try:
            response = self.api_call(headers=self.headers, method='GET',
                                     url=CITY_NAME_ENDPOINT.format(city_name=city_name))
            if response:
                return response.get('id')
        except Exception as e:
            logging.error(str(e), exc_info=True)

    def api_call(self, headers, method, url, data=None):
        try:
            response = requests.request(headers=headers, method=method, data=data, url=url)
            response.raise_for_status()
            print(url)
            print(response.json())
            return response.json()
        except requests.exceptions.HTTPError as errh:
            print("HTTP Error:", errh)
        except requests.exceptions.ConnectionError as errc:
            print("Error Connecting:", errc)
        except requests.exceptions.Timeout as errt:
            print("Timeout Error:", errt)
        except requests.exceptions.RequestException as err:
            print("Oops: Something Else", err)


        def read_city_data_from_database(self, city_name):
            try:
                self.search_city_by_name = CandidateCitySearch()
                response_id = self.search_city_by_name.city_name_parse_by_name(city_name)
                print("This is the response of data", response_id)
                if response_id is None:
                    self.ai_generate_city_name(city_name)
                    return self.ai_generate_city_name
                return response_id
            except Exception as e:
                logging.warning("Error during city data retrieval", str(e))

        def ai_generate_city_name(self, city_name):
            response = self.model.generate_content(
                f"{CITY_INFO}:{city_name} and given me response in this format {CITY_RESPONSE}")
            ai_response = response.text
            response2 = self.model.generate_content(
                f"Based on this city_name data {ai_response} what is the new name of city_name {CITY_COMPARSION},given me {CITY_RESPONSE}")
            ai_response2 = response2.text
            final_response_of_ai = self.model.generate_content(f"proper json format {ai_response2}")
            response_of_ai_of_city = final_response_of_ai.text
            response = self._handle_city_response(response_of_ai_of_city)
            print("This is the response of AI", response)
            return response

        def _handle_city_response(self, response):
            try:
                self.city_response = response
                print(self.city_response)
                logging.info(self.city_response)
                clean_city_response = self.city_response.replace('```', "").replace('json', "").replace('JSON',
                                                                                                        "").replace(
                    '\n', '')
                city_data = json.loads(clean_city_response)
                if 'city_name' in city_data and city_data['city_name'] is not None:
                    city_data['city_name'] = city_data['city_name'].upper()

                logging.info(f"city information {city_data}")
                city_name = city_data.get('city_name')
                response_of_ai_city_name = self.search_city_by_name.city_name_parse_by_name(city_name)
                if response_of_ai_city_name is None:
                    # self.search_city_by_name.update_city_into_city_table(city_name)
                    response_of_ai_city_name = self.search_city_by_name.update_city_into_city_table(
                        response_of_ai_city_name)
                return response_of_ai_city_name

            except json.JSONDecodeError as e:
                logging.warning(f"Error decoding City JSON: {e}")
            except Exception as ex:
                logging.error(f"Error manipulating city data in database: {ex}")"""

